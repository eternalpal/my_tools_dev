---
name: m3u8-decrypt-download
description: 下载 m3u8 视频流并合并为 mp4，重点解决 AES-128 加密流的解密问题。当用户提供 .m3u8 链接要求下载/保存/合并成视频文件（mp4/mkv）时使用，尤其是播放列表含 #EXT-X-KEY 的加密流。内置绕开 ffmpeg 卡死的标准流程。
agent_created: true
---

# 加密 m3u8 下载与解密合并

## 何时使用

- 用户给出 `.m3u8` 链接，要求"下载这个视频 / 保存为 xx.mp4"
- HLS 分片下载后需要按序合并
- **播放列表里含 `#EXT-X-KEY:METHOD=AES-128`**

## 核心陷阱：别直接用 ffmpeg 拉加密 HLS

**症状**：`ffmpeg -i xxx.m3u8 -c copy out.mp4` 进程存活，但输出文件卡在几 MB 完全不动（跑了数分钟），
即使加上 `-allowed_extensions ALL -protocol_whitelist file,crypto,data` 也无效。实测 ffmpeg 4.0.2 必现。

**正解**：绕开 ffmpeg 的 HLS 解密层——**先手动 AES 解密每个分片，再用 concat 合并**。
解密后的明文 TS 走 concat 非常稳定（实测 2117 片 / 1.7GB 约 30 秒完成）。

> 无加密的 m3u8（`METHOD=NONE`）可以直接让 ffmpeg 拉，不在此坑范围内。

## 标准流程

### 1. 探测播放列表

```bash
curl -s -A "<UA>" -e "<页面URL>" --max-time 25 "<m3u8_url>" -o index.m3u8
head -20 index.m3u8
```

关注三件事：
- **是否加密：看 `#EXT-X-KEY` 的 `METHOD` 值**——只有 `METHOD=AES-128` 才是真加密。
  `METHOD=NONE` 表示"声明了但没加密"。**只检索 `EXT-X-KEY` 关键字会误判成加密**（踩过，
  白白走一遍解密流程）。确认加密后再看 URI（相对/绝对）和 IV。
  拿不准就抽查分片首字节：明文 TS 必为 `0x47`。
- 是 **master 还是 media** 播放列表？若是 master（含多个 `分辨率.m3u8`），需先选一路再重复本步
- 分片 URL 是绝对还是相对（相对需与 m3u8 基址拼接）

**Referer 很关键**：多数站点校验防盗链，缺失会 403。取播放页地址；分片与 m3u8 跨域时（如 m3u8 在
`a.com`、分片在 `b.com`）通常沿用播放页 referer 即可。

### 2. 下载密钥与分片

用 `scripts/m3u8_dl.py`（24 并发，支持断点续传与重试）：

```bash
python m3u8_dl.py "<m3u8_url>" --referer "<页面URL>" -o workdir
```

产出：`workdir/index.m3u8`、`workdir/enc.key`、`workdir/ts/seg_00000.ts ...`

> **少数分片超时失败是常态**（实测 4158 片里有 2 片 `read operation timed out`）。
> 直接**重跑同一条命令就能补齐**——脚本会跳过已存在的文件，补 2 片只要 4 秒，不必全量重下。
> 失败清单写在 `workdir/failed.txt`。合并前务必确认补到 0 失败，否则 concat 会因缺文件报错。

> **先检查磁盘**：`df -h`。分片总体积 ≈ 成品体积，还需预留同等空间放成品。

### 3. 手动 AES-128-CBC 解密（关键步骤）

```bash
python m3u8_dec.py --ts-dir workdir/ts --key workdir/enc.key --iv 00000000000000000000000000000000
```

要点：
- **IV**：取 m3u8 `#EXT-X-KEY` 里的 `IV=0x...`（常见全零 `IV=0x00000000000000000000000000000000`
  → 传入 32 个 0）。若该属性**不存在**，则是隐式 IV = 分片的 media sequence 序号（16 字节大端），
  此时需逐片用不同 IV 解密。
- **截断到 188 字节对齐**：AES-CBC 会把分片补齐到 16 的倍数，尾部残留非 TS 数据。
  解密后必须 `data[: len(data)//188*188]` 截断（TS 包固定 188 字节）。
- **原地覆盖**可省一半磁盘（解密后原文件无用）。
- 解密后**首字节必须是 `0x47`**（TS 同步字节），这是最直接的解密正确性判据。

### 4. 合并

```bash
python -c "
import os
files=sorted(f for f in os.listdir('workdir/ts') if f.endswith('.ts'))
open('list.txt','w',encoding='utf-8').write('\n'.join(\"file 'workdir/ts/%s'\"%f for f in files))
"
ffmpeg -y -f concat -safe 0 -i list.txt -c copy -bsf:a aac_adtstoasc -f mp4 out.mp4
```

`-bsf:a aac_adtstoasc` 用于把 TS 中的 ADTS 封装 AAC 转成 MP4 需要的 ASC，避免音画问题。

### 5. 校验

解密后逐片校验 `0x47` 已由脚本完成；成品再抽样验证：

```bash
# 多点抽样解码（比全片扫描快得多，全片扫 2 小时素材易被超时中断）
for t in 00:00:05 00:36:00 01:12:00 01:48:00 02:24:00; do
  r=$(ffmpeg -v error -ss $t -i out.mp4 -frames:v 3 -f null - 2>&1 | head -3)
  [ -z "$r" ] && echo "$t OK" || echo "$t FAIL: $r"
done
```

再 `ffmpeg -i out.mp4` 确认 Duration 与源 m3u8 的 `#EXTINF` 总和一致。

## 收尾

成品验证无误后，清理 `workdir/ts`（最大的中间产物）、`enc.key`、`list.txt`。
成品体积大，注意磁盘余量。

## 环境依赖

AES 解密需要 `pycryptodome`。装到隔离 venv，不要污染系统环境：

```bash
pip install pycryptodome
```

## 踩坑备忘

- **Git Bash 下 `taskkill //PID` 会被路径转换破坏**，报"无效参数"。杀进程改用 PowerShell：
  `Stop-Process -Id <pid> -Force`。
- 分片下载前**先试下 1 片**，用 `curl -w "%{http_code}"` 确认 200 且体积正常，避免白跑 2000 片。
- 判断分片是否加密：解密前若前几字节是 `47` 开头说明未加密；是随机字节则说明加密。
- 部分站点分片带时效性 query（`?hash=...`），下载要一气呵成，别间隔太久导致签名过期。
- **判断内容是否完整要"比对时长"，不能只看分片数**：下载器的分片文件与 m3u8 段未必 1:1。
  曾据"本地 316 片 vs 源 1854 段"误判视频残缺，实际成品时长与源 `totalDuration` 吻合、是完整的。
- **上千分片时，并发下载远快于 ffmpeg 直拉**：ffmpeg 串行拉，每个分片都要一次 HTTPS 握手，
  4158 片粗估 1h+；24 并发实测 938s。参考速度约 4~12 片/秒，取决于片源服务器响应。
  未加密流虽然可以直拉（省磁盘），但分片数多时反而更慢。
