#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AES-128-CBC 解密 m3u8 分片（原地覆盖，截断到 TS 包对齐，校验同步字节）。

用法:
    # 显式 IV 为全零（最常见，m3u8 里写作 IV=0x00000000000000000000000000000000）
    python m3u8_dec.py --ts-dir workdir/ts --key workdir/enc.key

    # 显式指定 IV（可带 0x 前缀）
    python m3u8_dec.py --ts-dir workdir/ts --key workdir/enc.key --iv 0x1234...（32位hex）

    # 隐式 IV：m3u8 没有 IV 属性时，IV = 分片序号（16 字节大端）
    python m3u8_dec.py --ts-dir workdir/ts --key workdir/enc.key --implicit-iv

    # 保留原始密文，解密结果另存
    python m3u8_dec.py --ts-dir workdir/ts --key workdir/enc.key --out-dir workdir/dec

需要 pycryptodome:  pip install pycryptodome
"""
import argparse
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    from Crypto.Cipher import AES
except ImportError:
    sys.exit("缺少 pycryptodome，请先安装:  pip install pycryptodome")

TS_PKT = 188


def resolve_iv(iv_hex, implicit, idx):
    if implicit:
        return idx.to_bytes(16, "big")
    if not iv_hex:
        return bytes(16)
    h = iv_hex[2:] if iv_hex.lower().startswith("0x") else iv_hex
    b = bytes.fromhex(h)
    return b.rjust(16, b"\x00")[-16:]


def decrypt(args):
    idx, src, dst, key, iv_hex, implicit = args
    try:
        with open(src, "rb") as f:
            data = f.read()
        iv = resolve_iv(iv_hex, implicit, idx)
        dec = AES.new(key, AES.MODE_CBC, iv).decrypt(data)
        # 截断到 TS 包边界，去掉 AES 补齐的尾部残留
        dec = dec[: (len(dec) // TS_PKT) * TS_PKT]
        if not dec or dec[0] != 0x47:
            return idx, False, "同步字节异常: %s" % dec[:1].hex()
        tmp = dst + ".dec"
        with open(tmp, "wb") as f:
            f.write(dec)
        os.replace(tmp, dst)
        return idx, True, len(dec)
    except Exception as e:
        return idx, False, str(e)


def main():
    ap = argparse.ArgumentParser(description="解密 m3u8 分片")
    ap.add_argument("--ts-dir", required=True, help="分片目录")
    ap.add_argument("--key", required=True, help="AES 密钥文件")
    ap.add_argument("--iv", default="", help="显式 IV（hex，可带 0x 前缀），默认全零")
    ap.add_argument("--implicit-iv", action="store_true",
                    help="隐式 IV：用分片序号作为 IV")
    ap.add_argument("--out-dir", default="", help="解密输出目录，默认原地覆盖")
    ap.add_argument("--workers", type=int, default=16)
    args = ap.parse_args()

    files = sorted(f for f in os.listdir(args.ts_dir)
                   if f.startswith("seg_") and f.endswith(".ts"))
    if not files:
        sys.exit("未在 %s 找到 seg_*.ts 分片" % args.ts_dir)

    key = open(args.key, "rb").read()
    out_dir = args.out_dir or args.ts_dir
    if out_dir != args.ts_dir:
        os.makedirs(out_dir, exist_ok=True)

    print("待解密: %d 片, 密钥 %d 字节, IV模式=%s"
          % (len(files), len(key), "隐式(序号)" if args.implicit_iv else ("显式 %s" % (args.iv or "全零"))), flush=True)

    tasks = [(i,
              os.path.join(args.ts_dir, f),
              os.path.join(out_dir, f),
              key, args.iv, args.implicit_iv)
             for i, f in enumerate(files)]

    ok, failed, t0 = 0, [], time.time()
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = [ex.submit(decrypt, t) for t in tasks]
        done = 0
        for fut in as_completed(futs):
            idx, success, info = fut.result()
            done += 1
            if success:
                ok += 1
            else:
                failed.append((idx, info))
            if done % 200 == 0 or done == len(tasks):
                print("进度 %d/%d  成功 %d  失败 %d  %.0fs"
                      % (done, len(tasks), ok, len(failed), time.time() - t0), flush=True)

    print("\n解密完成: 成功 %d / %d, 失败 %d, 用时 %.0fs"
          % (ok, len(tasks), len(failed), time.time() - t0))
    if failed:
        print("失败(前20): %s" % failed[:20])
        sys.exit(1)
    print("全部通过同步字节(0x47)校验，可执行 concat 合并")


if __name__ == "__main__":
    main()
