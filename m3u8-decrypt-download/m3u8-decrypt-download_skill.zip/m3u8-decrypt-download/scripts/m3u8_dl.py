#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""下载 m3u8 播放列表、AES 密钥与全部分片。

用法:
    python m3u8_dl.py "<m3u8_url>" --referer "<播放页URL>" -o workdir
    python m3u8_dl.py "<m3u8_url>" -o workdir --variant best --workers 24

产出:
    workdir/index.m3u8   原始播放列表（已解析后的 media playlist）
    workdir/enc.key      AES 密钥（若加密）
    workdir/ts/seg_00000.ts ...   按序命名的分片
"""
import argparse
import os
import re
import sys
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")


def fetch(url, headers, timeout=30, retry=4):
    last = None
    for i in range(retry):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except Exception as e:
            last = e
            time.sleep(1.2 * (i + 1))
    raise RuntimeError("下载失败 %s : %s" % (url, last))


def parse_m3u8(text):
    """解析播放列表。返回 (is_master, variants, key_uri, iv_hex, segs, total_dur)

    variants: master 时为 [(bandwidth, url), ...]
    segs:     media 时为分片 URL 列表（保持顺序）
    """
    is_master = "#EXT-X-STREAM-INF" in text
    variants, segs = [], []
    key_uri = iv_hex = None
    pending_bw, pending_dur = None, None

    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#EXT-X-KEY"):
            m = re.search(r'URI="([^"]+)"', line)
            if m:
                key_uri = m.group(1)
            m = re.search(r'IV=0x([0-9A-Fa-f]+)', line)
            if m:
                iv_hex = m.group(1)
        elif line.startswith("#EXT-X-STREAM-INF"):
            m = re.search(r"BANDWIDTH=(\d+)", line)
            pending_bw = int(m.group(1)) if m else 0
        elif line.startswith("#EXTINF"):
            m = re.search(r"#EXTINF:([0-9.]+)", line)
            pending_dur = float(m.group(1)) if m else 0.0
        elif not line.startswith("#"):
            if is_master:
                variants.append((pending_bw or 0, line))
                pending_bw = None
            else:
                segs.append(line)
                pending_dur = None

    total_dur = sum(
        float(m) for m in re.findall(r"#EXTINF:([0-9.]+)", text)
    )
    return is_master, variants, key_uri, iv_hex, segs, total_dur


def download_one(args):
    idx, url, path, headers = args
    if os.path.exists(path) and os.path.getsize(path) > 0:
        return idx, True, "skip"
    try:
        data = fetch(url, headers, retry=3)
        if not data:
            raise ValueError("空响应")
        tmp = path + ".part"
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, path)
        return idx, True, len(data)
    except Exception as e:
        return idx, False, str(e)


def main():
    ap = argparse.ArgumentParser(description="下载 m3u8 及其分片")
    ap.add_argument("url", help="m3u8 地址")
    ap.add_argument("-o", "--out", default="m3u8_work", help="输出目录")
    ap.add_argument("--referer", default="", help="Referer（多数站点需要）")
    ap.add_argument("--workers", type=int, default=24, help="并发数")
    ap.add_argument("--variant", default="best",
                    help="master 列表选路: best(最高码率)/first/索引号")
    args = ap.parse_args()

    headers = {"User-Agent": UA, "Accept": "*/*"}
    if args.referer:
        headers["Referer"] = args.referer

    ts_dir = os.path.join(args.out, "ts")
    os.makedirs(ts_dir, exist_ok=True)

    # 1) 取播放列表
    print("获取播放列表: %s" % args.url, flush=True)
    text = fetch(args.url, headers).decode("utf-8", "ignore")
    is_master, variants, key_uri, iv_hex, segs, total_dur = parse_m3u8(text)

    # 2) master 则选一路
    if is_master:
        if not variants:
            sys.exit("master 播放列表未解析到子流")
        variants.sort(key=lambda x: x[0], reverse=True)
        if args.variant == "best":
            pick = 0
        elif args.variant == "first":
            pick = len(variants) - 1
        else:
            pick = int(args.variant)
        bw, sub = variants[pick]
        print("master 列表，共 %d 路，选择带宽 %d -> %s" % (len(variants), bw, sub), flush=True)
        sub_url = urllib.parse.urljoin(args.url, sub)
        text = fetch(sub_url, headers).decode("utf-8", "ignore")
        is_master, variants, key_uri, iv_hex, segs, total_dur = parse_m3u8(text)
        args.url = sub_url

    with open(os.path.join(args.out, "index.m3u8"), "w", encoding="utf-8") as f:
        f.write(text)

    print("分片数: %d, 预估时长: %.0f 秒 (%.1f 分钟)" % (len(segs), total_dur, total_dur / 60), flush=True)

    # 3) 下载密钥
    if key_uri:
        key_url = urllib.parse.urljoin(args.url, key_uri)
        key = fetch(key_url, headers)
        with open(os.path.join(args.out, "enc.key"), "wb") as f:
            f.write(key)
        print("密钥已保存: %d 字节, IV=%s" % (len(key), iv_hex or "(未指定/隐式)"), flush=True)
    else:
        print("该流未加密（无 EXT-X-KEY），可直接合并", flush=True)

    # 4) 并发下载分片
    tasks = []
    for i, s in enumerate(segs):
        full = urllib.parse.urljoin(args.url, s)
        tasks.append((i, full, os.path.join(ts_dir, "seg_%05d.ts" % i), headers))

    ok, failed, t0 = 0, [], time.time()
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = [ex.submit(download_one, t) for t in tasks]
        done = 0
        for fut in as_completed(futs):
            idx, success, info = fut.result()
            done += 1
            if success:
                ok += 1
            else:
                failed.append((idx, info))
            if done % 100 == 0 or done == len(tasks):
                print("进度 %d/%d  成功 %d  失败 %d  %.0fs"
                      % (done, len(tasks), ok, len(failed), time.time() - t0), flush=True)

    print("\n下载完成: 成功 %d / %d, 失败 %d, 用时 %.0fs" % (ok, len(tasks), len(failed), time.time() - t0))
    if failed:
        with open(os.path.join(args.out, "failed.txt"), "w", encoding="utf-8") as f:
            for idx, err in failed:
                f.write("%d\t%s\t%s\n" % (idx, tasks[idx][1], err))
        print("失败清单: %s/failed.txt （可重跑本命令续传）" % args.out)
        sys.exit(1)


if __name__ == "__main__":
    main()
