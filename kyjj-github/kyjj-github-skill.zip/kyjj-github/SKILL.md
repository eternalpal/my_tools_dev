---
name: kyjj-github
description: 将一组 GitHub 仓库地址转化为「小金」风格的公众号开源项目推荐文章。This skill should be used when the user provides one or more GitHub repo URLs (or says "github地址"/"几个开源项目") and wants an article that introduces each project with a casual, click-worthy 公众号 tone, 3 alternative titles, and a fixed per-project template. Triggers include "把这些 github 链接写成文章", "输入 github 地址输出文章", "整理几个开源项目发公众号".
agent_created: true
---

# Kyjj Github

## Overview

把用户给的一个或多个 GitHub 仓库地址，自动抓取内容后，重写成「小金」口吻的公众号风格开源项目推荐文章。产出包含：3 个吸睛备选标题 + 按序排列的项目简介（每个含功能、适用场景、从 README 提取的配图与项目地址）。不含开头结尾闲聊。仅输出 Markdown 文件，不额外生成 HTML。

## When To Use

- 用户直接粘贴 GitHub 仓库 URL（如 `https://github.com/owner/repo`），要求写成推荐文章。
- 用户表达「把这些开源项目整理成文章」「输入 github 地址输出文章」「发篇公众号推荐」。
- 用户提供了若干 GitHub 链接并希望依次介绍、带标题。

不适用：单纯的代码阅读、克隆、运行仓库，或不需要「小金」风格文章的场景。

## Workflow

### Step 1 — 收集仓库地址

从用户消息中提取全部 GitHub 仓库 URL，记录顺序（序号 01、02……以此为准）。若用户未明确数量，按实际给出的链接数处理。

### Step 2 — 逐个抓取项目内容与配图

对每个 URL：

1. 调用 WebFetch 提取项目信息，prompt 统一为：
   「请提取这个GitHub项目的：项目名称、一句话简介、主要功能特性、适用场景/用途、标签(topics)。请尽量保留原文的关键信息。」
2. 另外抓取 README 原文，提取其中出现的图片直链（markdown `![alt](url)` 与 HTML `<img src="...">`），并把相对路径解析为基于 `raw.githubusercontent.com` 的绝对地址（以 README 所在目录为基准）。优先挑选有信息量的界面截图、Demo 动图、架构/流程示意图、Logo；跳过 CI 徽章、shields 这类纯徽标。
3. 校验每个图片 URL 可访问：先用 HEAD 请求（`curl -sIL`），若返回 `000`（环境拦截 HEAD），改用 `curl -sL -r 0-1024` 的 Range GET 兜底，返回 206/200 且 content_type 为 `image/*` 即为有效，剔除失效链接。

将「名称 / 简介 / 功能 / 场景 / 地址 / 图片URL列表」暂存，作为写作依据。功能描述必须忠于抓取内容，不得编造。

### Step 3 — 生成 3 个备选标题

按 references/article_template.md 中的「备选标题规范」生成 3 个公众号吸睛标题（身份代入 + 钩子 + 情绪词），标题中的数量 N 等于项目数。

### Step 4 — 按模板写项目模块

加载 `references/article_template.md`，严格按其「单个项目模块模板」「README 配图插入规范」与「小金口吻规范」生成文章：

- 文首只用引用块 `>` 列出 3 个备选标题，不要额外开场白。
- 每个项目：`### 序号 项目名（英文原名）` + 1-2 段简介（第 1 段讲「是什么/核心」，第 2 段讲「亮点+适用场景」）+ 若干张 README 配图（标准 markdown `![](url)` 语法，放在简介与项目地址之间）+ `项目地址` 代码块（原始 URL）。
- 全篇不写开头寒暄与结尾碎碎念。

### Step 5 — 输出与展示

将成品写入 Markdown 文件（默认当前工作目录，文件名默认 `github项目推荐.md`，用户另有指定则遵从），随后调用 present_files 展示该文件。仅输出 Markdown，不额外生成 HTML 等格式。

## Resources

### references/

- `article_template.md` — 文章模板、备选标题规范、小金口吻规范、标准执行流程。生成文章前务必读取并遵循。

## Notes

- 尊重原意：所有功能点与适用场景须来自实际抓取的项目 README，不夸大、不编造、不涉及政治敏感内容。
- 口语化适度：网感词汇可用但勿堆砌；保持可读。
- 项目地址保留原始 URL，不要改写 host 或加参数。
- 配图规范：图片用 README 中的原始直链（如 raw.githubusercontent.com），不要下载到本地或改写 host；每个项目插入 1–3 张最能说明项目的图，插入前必须做可访问性校验（HTTP 200），杜绝裂图。
- 输出格式：仅生成 Markdown 文件，不额外产出 HTML。
